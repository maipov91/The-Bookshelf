document.addEventListener('DOMContentLoaded', () => {
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const loginBtn = document.getElementById('loginBtn');
  const loginError = document.getElementById('loginError');

  if (localStorage.getItem(CONFIG.STORAGE.TOKEN)) {
    window.location.href = 'chat.html';
    return;
  }

  loginBtn.addEventListener('click', handleLogin);

  passwordInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
      handleLogin();
    }
  });

  usernameInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
      passwordInput.focus();
    }
  });

  async function handleLogin() {
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    loginError.classList.remove('show');

    if (!username || !password) {
      showError('Vui long nhap tai khoan va mat khau');
      return;
    }

    loginBtn.disabled = true;
    loginBtn.textContent = 'Signing in...';

    try {
      const response = await fetch(`${CONFIG.API_BASE}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Login failed');
      }

      localStorage.setItem(CONFIG.STORAGE.TOKEN, data.token);
      localStorage.setItem(CONFIG.STORAGE.USER, JSON.stringify(withAvatar(data.user)));
      localStorage.setItem(CONFIG.STORAGE.PEER, JSON.stringify(withAvatar(data.peer)));

      window.location.href = 'chat.html';
    } catch (error) {
      showError(error.message || 'Cannot connect to server');
    } finally {
      loginBtn.disabled = false;
      loginBtn.textContent = 'Sign In';
    }
  }

  function showError(message) {
    loginError.textContent = message;
    loginError.classList.add('show');
    loginError.style.animation = 'none';
    loginError.offsetHeight;
    loginError.style.animation = 'shake 0.4s ease';
  }

  function withAvatar(account) {
    return {
      ...account,
      avatar: getInitials(account.displayName || account.username)
    };
  }

  function getInitials(name) {
    return String(name || '')
      .split(' ')
      .map((word) => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  }
});
