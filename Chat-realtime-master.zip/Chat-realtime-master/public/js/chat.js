document.addEventListener('DOMContentLoaded', () => {
  const token = localStorage.getItem(CONFIG.STORAGE.TOKEN);
  const currentUser = readJson(CONFIG.STORAGE.USER);
  const peerUser = readJson(CONFIG.STORAGE.PEER);

  if (!token || !currentUser || !peerUser) {
    clearSession();
    window.location.href = 'index.html';
    return;
  }

  const conversationsList = document.getElementById('conversationsList');
  const searchInput = document.getElementById('searchInput');
  const currentUserName = document.getElementById('currentUserName');
  const currentUserAvatar = document.getElementById('currentUserAvatar');
  const settingsBtn = document.getElementById('settingsBtn');
  const settingsDropdown = document.getElementById('settingsDropdown');
  const logoutBtn = document.getElementById('logoutBtn');
  const noChatView = document.getElementById('noChatView');
  const chatView = document.getElementById('chatView');
  const chatAvatar = document.getElementById('chatAvatar');
  const chatName = document.getElementById('chatName');
  const chatStatus = document.getElementById('chatStatus');
  const messagesContainer = document.getElementById('messagesContainer');
  const messageInput = document.getElementById('messageInput');
  const sendBtn = document.getElementById('sendBtn');
  const typingIndicator = document.getElementById('typingIndicator');

  const conversation = {
    id: 'user-admin',
    name: peerUser.displayName || peerUser.username,
    avatar: peerUser.avatar || getInitials(peerUser.displayName || peerUser.username),
    avatarColor: peerUser.role === 'admin' ? 'avatar-orange' : 'avatar-khaki',
    online: true,
    lastMessage: 'Start chatting...',
    unread: 0,
    messages: []
  };

  let activeConversationId = null;
  let socket = null;

  initUI();
  loadMessages();
  connectSocket();

  function initUI() {
    currentUserName.textContent = currentUser.displayName || currentUser.username;
    currentUserAvatar.textContent =
      currentUser.avatar || getInitials(currentUser.displayName || currentUser.username);

    renderConversations([conversation]);
    setupEventListeners();
    openConversation(conversation.id);
  }

  async function api(path, options = {}) {
    const response = await fetch(`${CONFIG.API_BASE}${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        ...options.headers
      }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'Request failed');
    }

    return data;
  }

  async function loadMessages() {
    try {
      const data = await api('/messages');
      conversation.messages = data.messages.map(toUiMessage);
      updateLastMessage();
      renderConversations([conversation]);
      renderMessages(conversation.messages);
      scrollToBottom();
    } catch (error) {
      showSystemMessage(error.message || 'Cannot load messages');
    }
  }

  function connectSocket() {
    socket = io(CONFIG.SERVER_URL, {
      auth: { token }
    });

    socket.on('connect', () => {
      setOnline(true);
    });

    socket.on('disconnect', () => {
      setOnline(false);
    });

    socket.on('connect_error', (error) => {
      showSystemMessage(error.message || 'Socket connection failed');
    });

    socket.on(CONFIG.EVENTS.RECEIVE_MESSAGE, (message) => {
      if (conversation.messages.some((item) => item.id === message.id)) {
        return;
      }

      const uiMessage = toUiMessage(message);
      conversation.messages.push(uiMessage);
      updateLastMessage();
      renderConversations([conversation]);

      if (activeConversationId === conversation.id) {
        addMessageToDOM(uiMessage);
        scrollToBottom();
      } else {
        conversation.unread += 1;
      }
    });
  }

  function renderConversations(conversations) {
    conversationsList.innerHTML = '';

    conversations.forEach((conv) => {
      const el = document.createElement('div');
      el.className = `conv-item${conv.id === activeConversationId ? ' active' : ''}`;
      el.dataset.id = conv.id;

      el.innerHTML = `
        <div class="avatar ${conv.avatarColor}">
          ${escapeHtml(conv.avatar)}
          <div class="status-dot ${conv.online ? 'online' : 'offline'}"></div>
        </div>
        <div class="conv-info">
          <div class="conv-name">${escapeHtml(conv.name)}</div>
          <div class="conv-last">${escapeHtml(conv.lastMessage)}</div>
        </div>
        ${conv.unread > 0 ? `<div class="unread-badge">${conv.unread}</div>` : ''}
      `;

      el.addEventListener('click', () => openConversation(conv.id));
      conversationsList.appendChild(el);
    });
  }

  function openConversation(convId) {
    activeConversationId = convId;
    conversation.unread = 0;

    renderConversations([conversation]);

    noChatView.style.display = 'none';
    chatView.style.display = 'flex';

    chatAvatar.textContent = conversation.avatar;
    chatAvatar.className = `avatar sm ${conversation.avatarColor}`;
    chatName.textContent = conversation.name;
    setOnline(conversation.online);

    renderMessages(conversation.messages);
    scrollToBottom();
    messageInput.focus();
  }

  function renderMessages(messages) {
    messagesContainer.innerHTML = '';

    const dateSep = document.createElement('div');
    dateSep.className = 'date-separator';
    dateSep.innerHTML = '<span>Today</span>';
    messagesContainer.appendChild(dateSep);

    messages.forEach(addMessageToDOM);
  }

  function addMessageToDOM(message) {
    const el = document.createElement('div');
    el.className = `msg ${message.sender === 'me' ? 'sent' : 'received'}`;
    el.dataset.id = message.id;

    const bubble = document.createElement('div');
    bubble.className = 'msg-bubble';
    bubble.textContent = message.text;

    const time = document.createElement('div');
    time.className = 'msg-time';
    time.textContent = message.time;

    el.append(bubble, time);
    messagesContainer.appendChild(el);
  }

  function sendMessage() {
    const text = messageInput.value.trim();

    if (!text || !activeConversationId || !socket?.connected) {
      return;
    }

    sendBtn.disabled = true;
    messageInput.value = '';

    socket.emit(CONFIG.EVENTS.SEND_MESSAGE, { content: text }, (response) => {
      sendBtn.disabled = false;
      messageInput.focus();

      if (!response?.ok) {
        messageInput.value = text;
        showSystemMessage(response?.message || 'Cannot send message');
      }
    });
  }

  function setupEventListeners() {
    sendBtn.addEventListener('click', sendMessage);

    messageInput.addEventListener('keypress', (event) => {
      if (event.key === 'Enter') {
        sendMessage();
      }
    });

    settingsBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      settingsDropdown.classList.toggle('show');
    });

    document.addEventListener('click', (event) => {
      if (!settingsDropdown.contains(event.target)) {
        settingsDropdown.classList.remove('show');
      }
    });

    logoutBtn.addEventListener('click', () => {
      if (socket) {
        socket.disconnect();
      }

      clearSession();
      window.location.href = 'index.html';
    });

    searchInput.addEventListener('input', (event) => {
      const query = event.target.value.toLowerCase();
      const visible = conversation.name.toLowerCase().includes(query)
        || conversation.lastMessage.toLowerCase().includes(query);

      renderConversations(visible ? [conversation] : []);
    });
  }

  function setOnline(online) {
    conversation.online = online;

    if (!chatStatus) {
      return;
    }

    chatStatus.innerHTML = online
      ? '<i class="ti ti-point-filled" style="font-size:12px;"></i> <span>online</span>'
      : '<span style="color:#9ca3af;">offline</span>';
  }

  function updateLastMessage() {
    const last = conversation.messages[conversation.messages.length - 1];
    conversation.lastMessage = last ? last.text : 'Start chatting...';
  }

  function toUiMessage(message) {
    return {
      id: message.id,
      sender: message.sender === currentUser.role ? 'me' : 'them',
      text: message.content,
      time: formatTime(message.createdAt)
    };
  }

  function showTypingIndicator(show) {
    typingIndicator.classList.toggle('show', show);

    if (show) {
      scrollToBottom();
    }
  }

  function showSystemMessage(message) {
    showTypingIndicator(false);

    const el = document.createElement('div');
    el.className = 'date-separator';
    el.innerHTML = `<span>${escapeHtml(message)}</span>`;
    messagesContainer.appendChild(el);
    scrollToBottom();
  }

  function scrollToBottom() {
    requestAnimationFrame(() => {
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    });
  }

  function formatTime(value) {
    const date = new Date(value);
    return date.getHours().toString().padStart(2, '0') + ':'
      + date.getMinutes().toString().padStart(2, '0');
  }

  function getInitials(name) {
    return String(name || '')
      .split(' ')
      .map((word) => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  }

  function readJson(key) {
    try {
      return JSON.parse(localStorage.getItem(key));
    } catch (error) {
      return null;
    }
  }

  function clearSession() {
    localStorage.removeItem(CONFIG.STORAGE.TOKEN);
    localStorage.removeItem(CONFIG.STORAGE.USER);
    localStorage.removeItem(CONFIG.STORAGE.PEER);
  }

  function escapeHtml(value) {
    const span = document.createElement('span');
    span.textContent = String(value || '');
    return span.innerHTML;
  }
});
