const CONFIG = {
  SERVER_URL: window.location.origin,
  API_BASE: `${window.location.origin}/api`,
  STORAGE: {
    TOKEN: 'bookshelf_token',
    USER: 'bookshelf_user',
    PEER: 'bookshelf_peer'
  },
  EVENTS: {
    SEND_MESSAGE: 'message:send',
    RECEIVE_MESSAGE: 'message:new'
  }
};
