const accounts = {
  user: {
    id: 'user',
    username: 'user',
    displayName: 'User',
    role: 'user',
    password: process.env.DEFAULT_USER_PASSWORD || '123456'
  },
  admin: {
    id: 'admin',
    username: 'admin',
    displayName: 'Admin',
    role: 'admin',
    password: process.env.DEFAULT_ADMIN_PASSWORD || '98765'
  }
};

function findAccount(username) {
  return accounts[String(username || '').trim().toLowerCase()] || null;
}

function getPeer(role) {
  return role === 'admin' ? accounts.user : accounts.admin;
}

function toPublicAccount(account) {
  return {
    id: account.id,
    username: account.username,
    displayName: account.displayName,
    role: account.role
  };
}

module.exports = {
  accounts,
  findAccount,
  getPeer,
  toPublicAccount
};
