require('dotenv').config();

const requiredEnv = ['JWT_SECRET', 'SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'];

function validateEnv() {
  const missing = requiredEnv.filter((key) => !process.env[key]);

  if (missing.length > 0) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }

  assertServiceRoleKey(process.env.SUPABASE_SERVICE_ROLE_KEY);
}

function assertServiceRoleKey(key) {
  const [, payload] = String(key).split('.');

  if (!payload) {
    return;
  }

  try {
    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));

    if (decoded.role && decoded.role !== 'service_role') {
      throw new Error(
        'SUPABASE_SERVICE_ROLE_KEY must be the Supabase service_role key, not the anon public key.'
      );
    }
  } catch (error) {
    if (error.message.includes('service_role')) {
      throw error;
    }
  }
}

module.exports = {
  validateEnv,
  port: Number(process.env.PORT || 3000),
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:3000',
  jwtSecret: process.env.JWT_SECRET,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '1d',
  supabaseUrl: process.env.SUPABASE_URL,
  supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY
};
