const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config/env');
const { findAccount, toPublicAccount } = require('../config/accounts');

function signToken(account) {
  return jwt.sign(
    {
      sub: account.id,
      username: account.username,
      role: account.role
    },
    jwtSecret,
    { expiresIn: process.env.JWT_EXPIRES_IN || '1d' }
  );
}

function authenticate(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ message: 'Missing access token.' });
  }

  try {
    const payload = jwt.verify(token, jwtSecret);
    const account = findAccount(payload.username);

    if (!account || account.role !== payload.role) {
      return res.status(401).json({ message: 'Invalid access token.' });
    }

    req.user = toPublicAccount(account);
    return next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid or expired access token.' });
  }
}

function authenticateSocket(socket, next) {
  const token = socket.handshake.auth?.token;

  if (!token) {
    return next(new Error('Missing access token.'));
  }

  try {
    const payload = jwt.verify(token, jwtSecret);
    const account = findAccount(payload.username);

    if (!account || account.role !== payload.role) {
      return next(new Error('Invalid access token.'));
    }

    socket.user = toPublicAccount(account);
    return next();
  } catch (error) {
    return next(new Error('Invalid or expired access token.'));
  }
}

module.exports = {
  signToken,
  authenticate,
  authenticateSocket
};
