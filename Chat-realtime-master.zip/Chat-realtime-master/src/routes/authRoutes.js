const express = require('express');
const { findAccount, getPeer, toPublicAccount } = require('../config/accounts');
const { signToken } = require('../middleware/auth');

const router = express.Router();

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const account = findAccount(username);

  if (!account || account.password !== String(password || '')) {
    return res.status(401).json({ message: 'Sai tài khoản hoặc mật khẩu.' });
  }

  return res.json({
    token: signToken(account),
    user: toPublicAccount(account),
    peer: toPublicAccount(getPeer(account.role))
  });
});

module.exports = router;
