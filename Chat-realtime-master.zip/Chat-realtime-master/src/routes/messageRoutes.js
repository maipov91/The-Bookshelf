const express = require('express');
const { authenticate } = require('../middleware/auth');
const { listConversation, createMessage } = require('../services/messageService');

const router = express.Router();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const messages = await listConversation(req.user.role);
    res.json({ messages });
  } catch (error) {
    next(error);
  }
});

router.post('/', authenticate, async (req, res, next) => {
  try {
    const message = await createMessage(req.user.role, req.body.content);
    res.status(201).json({ message });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
