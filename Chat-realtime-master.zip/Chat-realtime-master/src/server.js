const http = require('http');
const { Server } = require('socket.io');
const app = require('./app');
const registerSocket = require('./socket');
const { validateEnv, port, clientOrigin } = require('./config/env');

validateEnv();

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: clientOrigin,
    credentials: true
  }
});

registerSocket(io);

server.listen(port, () => {
  console.log(`Live chat server is running at http://localhost:${port}`);
});
