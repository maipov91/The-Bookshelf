const supabase = require('../config/supabase');
const { getPeer } = require('../config/accounts');

function normalizeMessage(row) {
  return {
    id: row.id,
    sender: row.sender,
    receiver: row.receiver,
    content: row.content,
    createdAt: row.created_at
  };
}

async function listConversation(role) {
  const peer = getPeer(role);

  const { data, error } = await supabase
    .from('messages')
    .select('id, sender, receiver, content, created_at')
    .or(
      `and(sender.eq.${role},receiver.eq.${peer.role}),and(sender.eq.${peer.role},receiver.eq.${role})`
    )
    .order('created_at', { ascending: true });

  if (error) {
    throw error;
  }

  return data.map(normalizeMessage);
}

async function createMessage(senderRole, content) {
  const text = String(content || '').trim();

  if (!text) {
    const error = new Error('Message content is required.');
    error.statusCode = 400;
    throw error;
  }

  if (text.length > 2000) {
    const error = new Error('Message content is too long.');
    error.statusCode = 400;
    throw error;
  }

  const receiver = getPeer(senderRole);

  const { data, error } = await supabase
    .from('messages')
    .insert({
      sender: senderRole,
      receiver: receiver.role,
      content: text
    })
    .select('id, sender, receiver, content, created_at')
    .single();

  if (error) {
    throw error;
  }

  return normalizeMessage(data);
}

module.exports = {
  listConversation,
  createMessage
};
