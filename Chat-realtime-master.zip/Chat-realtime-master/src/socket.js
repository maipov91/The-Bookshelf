const { authenticateSocket } = require('./middleware/auth');
const { createMessage } = require('./services/messageService');

function registerSocket(io) {
  io.use(authenticateSocket);

  io.on('connection', (socket) => {
    socket.join(socket.user.role);

    socket.emit('socket:ready', {
      user: socket.user
    });

    socket.on('message:send', async (payload, callback) => {
      try {
        const message = await createMessage(socket.user.role, payload?.content);

        io.to(message.sender).to(message.receiver).emit('message:new', message);

        if (typeof callback === 'function') {
          callback({ ok: true, message });
        }
      } catch (error) {
        if (typeof callback === 'function') {
          callback({
            ok: false,
            message: error.message || 'Cannot send message.'
          });
        }
      }
    });
  });
}

module.exports = registerSocket;
