create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender text not null check (sender in ('user', 'admin')),
  receiver text not null check (receiver in ('user', 'admin')),
  content text not null check (char_length(trim(content)) > 0),
  created_at timestamptz not null default now()
);

create index if not exists messages_created_at_idx on public.messages (created_at asc);
create index if not exists messages_sender_receiver_idx on public.messages (sender, receiver);

alter table public.messages enable row level security;

do $$
begin
  if not exists (
    select 1
    from pg_policies
    where schemaname = 'public'
      and tablename = 'messages'
      and policyname = 'service role can manage messages'
  ) then
    create policy "service role can manage messages"
    on public.messages
    for all
    using (auth.role() = 'service_role')
    with check (auth.role() = 'service_role');
  end if;
end
$$;
